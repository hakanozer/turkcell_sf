package com.turkcell.threedays.restcontroller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.turkcell.threedays.props.Prod;

@RestController
public class ProductRestController {
	
	List<Prod> ls = new ArrayList<Prod>();
	
	public ProductRestController() {
		dataResult();
	}
	
	
	private void dataResult() {
		for (int i = 0; i < 10; i++) {
			Prod pr = new Prod();
			pr.setId(i);
			pr.setTitle("Title : " + i);
			pr.setPrice(i);
			pr.setDesc("Desc " + i);
			ls.add(pr);
		}
	}


	@GetMapping("/allProduct")
	public Map<String, Object> allProduct() {
		Map<String, Object> hm = new LinkedHashMap();
		hm.put("statu", true);
		hm.put("size", 3);
		hm.put("products", ls );
		return hm;
	}
	
	
	@PostMapping("/search")
	public Map<String, Object> search( @RequestParam String title ) {
		Map<String, Object> hm = new LinkedHashMap();
		List<Prod> lsx = new ArrayList<Prod>();
		for (Prod item : ls) {
			if (item.getTitle().contains(title)) {
				lsx.add(item);
			}
		}
		hm.put("statu", true);
		hm.put("products", lsx );
		return hm;
	}
	
	
	
	@PostMapping("/insert")
	public Map<String, Object> insert( Prod pr ) {
		Map<String, Object> hm = new LinkedHashMap();
		hm.put("statu", true);
		ls.add(pr);
		hm.put("products", ls );
		return hm;
	}
	
	
	@PostMapping("/jsoninsert")
	public Map<String, Object> jsoninsert( @RequestBody Prod pr ) {
		Map<String, Object> hm = new LinkedHashMap();
		hm.put("statu", true);
		ls.add(pr);
		hm.put("products", ls );
		return hm;
	}
	
	

}
