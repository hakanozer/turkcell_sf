package com.turkcell.threedays.restcontroller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.turkcell.threedays.props.JsonData;
import com.turkcell.threedays.props.Note;
import com.turkcell.threedays.props.Product;
import com.turkcell.threedays.repositories.NoteRepository;

@RestController
public class NoteRestController {
	
	
	@Autowired NoteRepository noteRepository;
	
	@PostMapping("/noteInsert")
	public Map<String, Object> noteInsert( @Valid @RequestBody Note note ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		Note nt = noteRepository.saveAndFlush(note);
		hm.put("statu", true);
		hm.put("Note", nt);
		return hm;
	}
	
	
	@GetMapping("/allnote")
	public Map<String, Object> allnote( ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		List<Note> ls = noteRepository.findAll();
		hm.put("statu", true);
		hm.put("Notes", ls);
		return hm;
	}
	
	
	@PostMapping("/deletenote")
	public Map<String, Object> deletenote( int nid ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		
		noteRepository.deleteById( nid );
		
		hm.put("statu", true);
		hm.put("Delete id", nid);
		return hm;
	}
	
	
	@PostMapping("/singlenote")
	public Map<String, Object> singlenote( int nid ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		
		/*
		noteRepository.findAll().stream()
		.filter(item -> item.getNid() == nid)
		.forEach(item -> {
			hm.put("Single Note", item);
		});
		*/
		Note nt = noteRepository.findIdsingle(nid);
		hm.put("Single Note", nt);
		hm.put("statu", true);
		
		return hm;
	}
	
	
	// Error Handling
	@ResponseStatus( code = HttpStatus.BAD_REQUEST )
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, Object> error (  MethodArgumentNotValidException ex ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		List<String> errorList = new ArrayList<String>();
		hm.put("statu", false);
		ex.getBindingResult().getAllErrors().forEach( error -> {
			String filedName = ((FieldError) error).getField();
			errorList.add(filedName +" Messsage : " +error.getDefaultMessage());
		});
		hm.put("messages", errorList );
		return hm;
	}
	
	
	@GetMapping("/productCall")
	public Map<String, Object> serviceCall() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		
		// Async
		try {
			
			Runnable rn = () -> {
				String url = "https://www.jsonbulut.com/json/product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=0";
				RestTemplate restTemplate = new RestTemplate();
				ResponseEntity<String> result = restTemplate.getForEntity(url, String.class);
				
				Gson gs = new Gson();
				List<Product> prl = gs.fromJson(result.getBody(), JsonData.class).getProducts();
				
				prl.get(0).getBilgiler().forEach( item -> {
					System.out.println(item.getProductName());
				});
				hm.put("allProduct", prl);
			};
			new Thread(rn).start();
			
		} catch (Exception e) {
			System.err.println("Service Error : " + e);
		}
		
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			System.err.println("Sleep Error : " + e);
		}
		
		
		/*
		 	Sync
		 	
		 	String url = "https://www.jsonbulut.com/json/product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=0";
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> result = restTemplate.getForEntity(url, String.class);
			
			Gson gs = new Gson();
			List<Product> prl = gs.fromJson(result.getBody(), JsonData.class).getProducts();
			
			prl.get(0).getBilgiler().forEach( item -> {
				System.out.println(item.getProductName());
			});
			hm.put("allProduct", prl);
		 */
		
		
		// xml read
		try {
			String url = "https://www.tcmb.gov.tr/kurlar/today.xml";
			String data = Jsoup.connect(url).get().toString();
			Document doc = Jsoup.parse(data, "", Parser.xmlParser());
			
			Elements elements = doc.getElementsByTag("Currency");
			for( Element item : elements ) {
				String Isim = item.getElementsByTag("Isim").text();
				String ForexBuying = item.getElementsByTag("ForexBuying").text();
				System.out.println("Isim : " + Isim + " - ForexBuying : " + ForexBuying);
			}
			
		} catch (Exception e) {
			System.err.println("Xml Erro: " + e);
		}
		
		
		return hm;
	}
	
	

}
