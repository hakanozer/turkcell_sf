package com.turkcell.threedays.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.turkcell.threedays.props.Note;

@Repository
public interface NoteRepository extends JpaRepository<Note, Integer>  {
	
	
	// custom query
	@Query(" select n from Note n where n.nid = ?1 ")
	Note findIdsingle(int nid);
	
	
	

	
}
