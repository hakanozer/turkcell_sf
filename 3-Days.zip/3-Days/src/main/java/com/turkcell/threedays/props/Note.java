package com.turkcell.threedays.props;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

import org.hibernate.validator.constraints.Length;



@Entity
public class Note {
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	//@Length(min = 1, message = "Nid Min 1")
	private int nid;
	
	@NotEmpty(message = "Title Not Empty")
	private String title;
	
	@Length(min = 5, max = 1000, message = "Min 5 Max 1000 Char Space")
	private String detail;
	
	public int getNid() {
		return nid;
	}
	public void setNid(int nid) {
		this.nid = nid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	

}
