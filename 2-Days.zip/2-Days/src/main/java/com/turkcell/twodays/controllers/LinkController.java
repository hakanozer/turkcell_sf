package com.turkcell.twodays.controllers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.turkcell.twodays.props.User;

@Controller
public class LinkController {
	
	@Autowired DriverManagerDataSource db;
	
	@GetMapping("/link")
	public String link( Model model ) {
		model.addAttribute("ls", dataResult());
		return "link";
	}
	
	
	public List<User> dataResult() {
		List<User> ls = new ArrayList<User>();
		try {
			String query = "select * from user";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while(rs.next()) {
				User us = new User();
				us.setUid(rs.getInt("uid"));
				us.setEmail(rs.getString("email"));
				us.setPass(rs.getString("pass"));
				ls.add(us);
			}
		} catch (Exception e) {
			System.err.println("Data result Error : " + e);
		}
		return ls;
	}
	
	static User us = null;
	@GetMapping("/detail/{uid}")
	public String detail( @PathVariable int uid, Model model ) {
		
		
		dataResult().stream()
		.filter(item -> item.getUid() == uid)
		.forEach(item -> {
			us = item;
		});
		model.addAttribute("us" , us);
		
		return "detail";
	}
	
	

}
