package com.turkcell.twodays.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.turkcell.twodays.util.Util;

@Controller
public class DashboardController {
	
	@Autowired DriverManagerDataSource db;
	
	@GetMapping("/dashboard")
	public String dashboard( HttpServletRequest req ) {
		//userInsert();
		return Util.control("dashboard", req);
	}
	
	
	private void userInsert() {
		try {
			Connection conn = db.getConnection();
			String query = "insert into user values ( null, ?, ? )";
			PreparedStatement pre = conn.prepareStatement(query);
			pre.setString(1, "ahmet@ali.com");
			pre.setString(2, "12345");
			pre.executeUpdate();
		} catch (Exception e) {
			System.err.println("Connection Error : " + e);
		}
	}
	
	

}
