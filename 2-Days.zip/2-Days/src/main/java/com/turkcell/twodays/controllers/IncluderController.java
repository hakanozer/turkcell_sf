package com.turkcell.twodays.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IncluderController {
	
	@GetMapping("/css")
	public String css() {
		return "inc/css";
	}
	
	
	@GetMapping("/js")
	public String js() {
		return "inc/js";
	}
	
	
	@GetMapping("/nav")
	public String nav( Model model, HttpSession session ) {
		String mail = ""+ session.getAttribute("user");
		model.addAttribute("mail", mail);
		return "inc/nav";
	}

}
