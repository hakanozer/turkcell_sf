package com.turkcell.twodays.controllers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.turkcell.twodays.util.Util;

@Controller
public class LoginController {
	
	@Autowired DriverManagerDataSource db;

	@GetMapping({"","/"})
	public String login() {
		return "login";
	}
	
	
	@PostMapping("/userLogin")
	public String userLogin( 
			@RequestParam String email,
			@RequestParam String pass,
			@RequestParam(defaultValue = "") String remember_me,
			HttpSession session,
			HttpServletResponse res
			) {
		
		try {
			String query = "select * from user where email = ? and pass = ?";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			pre.setString(1, email);
			pre.setString(2, pass);
			ResultSet rs = pre.executeQuery();
			if (rs.next()) {
				// cookie control and create
				if (!remember_me.equals("")) {
					Cookie cookie = new Cookie("user_cookie", Util.sifrele(email, 3));
					cookie.setMaxAge(60 * 60 * 8);
					res.addCookie(cookie);
				}
				
				// session create
				session.setAttribute("user", email);
				return "redirect:/dashboard";
			}
			
			
		} catch (Exception e) {
			System.err.println("Login Error : " + e);
		}
		
		return "redirect:/";
	}
	
	
	@GetMapping("/exit")
	public String exit( HttpServletRequest req, HttpServletResponse res ) {
		
		// session clear
		req.getSession().removeAttribute("user");
		// all session remove
		req.getSession().invalidate();
		
		// cookie remove
		Cookie cookie = new Cookie("user_cookie", "");
		cookie.setMaxAge(0);
		res.addCookie(cookie);
		
		return "redirect:/";
	}
	
	
}
