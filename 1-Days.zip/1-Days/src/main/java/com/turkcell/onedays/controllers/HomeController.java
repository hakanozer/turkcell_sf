package com.turkcell.onedays.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.turkcell.onedays.props.User;


@Controller
public class HomeController {
	
	//ArrayList<String> ls = null;
	List<User> ls = new ArrayList<>();
	String err = "";
	
	@Autowired User us;
	
	
	public HomeController() {
		System.out.println("HomeController call");
		//ls = new ArrayList<>();
	}
	
	
	// home page
	@RequestMapping(name = "/", method = RequestMethod.GET)
	public String home( Model model, Random rd ) {
		
		if (!ls.contains(us)) {
			ls.add(0, us);
		}
		
		int rnd = rd.nextInt(100);
		model.addAttribute("data", "Sample Data " + rnd);
		model.addAttribute("ls", ls);
		if (!err.equals("")) {
			model.addAttribute("err", err);
			err = "";
		}
		return "home";
	}
	
	
	
	
	// form data pull
	/*
	@PostMapping("/userAdd")
	public String userAdd( 
			@RequestParam String name, 
			@RequestParam String email, 
			@RequestParam String tel
			) {
		
		System.out.println("name : " + name + " email : " + email + " tel : " + tel );
		return "home";
	}
	*/
	
	@PostMapping("/userAdd")
	public String userAdd( User us, Random rd) {
		if (us.getName().equals("")) {
			err = "Name field required";
		}else {
			us.setId(rd.nextInt(1000));
			ls.add(us);
			System.out.println( "id : " + us.getId() + " name : " + us.getName() + " email : " + us.getEmail() + " tel : " + us.getTel() );
			//model.addAttribute("ls", ls);
		}
		return "redirect:/";
	}
	
	
	@GetMapping("/deleteItem/{id}")
	public String deleteItem( @PathVariable(name = "id") int idx ) {
		int index = -1;
		int i = 0;
		for (User item : ls) {
			if (item.getId() == idx) {
				index = i;
				break;
			}
			i++;
		}
		if(index > -1)
		ls.remove(index);
		System.out.println("delete id : "+ idx);
		ls.removeIf( item -> item.getId() == idx );
		return "redirect:/";
	}
	


	

}