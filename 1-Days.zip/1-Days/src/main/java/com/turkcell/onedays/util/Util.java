package com.turkcell.onedays.util;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.turkcell.onedays.props.User;

@Configuration
public class Util {
	
	@Bean(name = "us")
	public User singleUser() {
		System.out.println("singleUser call()");
		User us = new User();
		us.setId(10);
		us.setName("Hasan Bilsin");
		us.setEmail("hasan@mail.com");
		us.setTel("12312321");
		return us;
	}

}
