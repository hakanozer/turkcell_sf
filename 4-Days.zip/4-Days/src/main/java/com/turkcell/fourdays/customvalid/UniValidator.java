package com.turkcell.fourdays.customvalid;

import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UniValidator implements ConstraintValidator<UniValid, String> {
	
	List<String> cities = Arrays.asList("Adana","İstanbul","Ankara", "İzmir");
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		return cities.contains(value);
	}

}
