package com.turkcell.fourdays.restcontroller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OwaspRestController {
	
	
	@GetMapping("/login")
	public Map<String, Object> login( @RequestParam String mail, @RequestParam String pass ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("mail", mail);
		hm.put("pass", pass);
		System.out.println("login @GetMapping call");
		return hm;
	}
	

}
