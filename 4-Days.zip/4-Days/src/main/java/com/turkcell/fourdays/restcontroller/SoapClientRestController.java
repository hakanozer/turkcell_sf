package com.turkcell.fourdays.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.turkcell.fourdays.soapclient.SoapClient;
import com.works.clientSoap.bindings.GetBookRequest;
import com.works.clientSoap.bindings.GetBookResponse;

@RestController
public class SoapClientRestController {
	
	@Autowired
	SoapClient soapClient;
	
	@PostMapping("/getBook")
	public GetBookResponse item( @RequestBody GetBookRequest req ) {
		return soapClient.getItemInfo(req);
	}
	

}
