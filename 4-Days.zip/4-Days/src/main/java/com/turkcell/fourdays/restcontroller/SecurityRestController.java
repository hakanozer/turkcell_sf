package com.turkcell.fourdays.restcontroller;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.turkcell.fourdays.props.Product;
import com.turkcell.fourdays.repositories.UserRepository;
import com.turkcell.fourdays.util.Util;

@RestController
public class SecurityRestController {
	
	@Autowired UserRepository userRepository;
	
	@GetMapping("/allUser")
	public Map<String, Object> allUser( @Valid @RequestBody Product pr ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("statu", true);
		hm.put("allUser", userRepository.findAll());
		hm.put("product", pr);
		Util.userStatu();
		return hm;
	}

} 



