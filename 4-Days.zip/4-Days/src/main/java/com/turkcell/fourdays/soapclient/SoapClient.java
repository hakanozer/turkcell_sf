package com.turkcell.fourdays.soapclient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.works.clientSoap.bindings.GetBookRequest;
import com.works.clientSoap.bindings.GetBookResponse;

@Service
public class SoapClient {
	
	@Autowired
	Jaxb2Marshaller jaxb2Marshaller;
	
	
	private WebServiceTemplate serviceTemplate;
	String uri = "http://localhost:9090/ws/";
	
	public GetBookResponse getItemInfo( GetBookRequest itemRequest ) {
		serviceTemplate = new WebServiceTemplate(jaxb2Marshaller);
		GetBookResponse response = (GetBookResponse) serviceTemplate.marshalSendAndReceive(uri, itemRequest);
		return response;
	}
	
	/*
	public GetBookResponse getItem(GetBookRequest itemRequest){
        webServiceTemplate = new WebServiceTemplate(marshaller);
        return (GetBookResponse) webServiceTemplate.marshalSendAndReceive("http://localhost:9091/ws",itemRequest, new WebServiceMessageCallback() {
			
			@Override
			public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
				try {
					SoapHeader header = ((SoapMessage) message).getSoapHeader();
					QName name = new QName("token");
					header.addAttribute(name, "yRQYnWzskCZUxPwaQupWkiUzKELZ49eM7oWxAQK_ZXw");
				} catch (Exception e) {
					System.err.println("error : " + e);
				}
			}
			
		});
    }
    */
	
	
	
	

}
