package com.turkcell.fourdays.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.turkcell.fourdays.props.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

}
