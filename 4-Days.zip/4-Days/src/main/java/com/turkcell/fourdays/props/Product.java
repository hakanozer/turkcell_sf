package com.turkcell.fourdays.props;

import com.turkcell.fourdays.customvalid.UniValid;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Product {

	private int id;
	private String title;
	private String desc;
	
	@UniValid(message = "Lütfen beklenen şehri yazınız")
	private String city;
	
	
	
}
