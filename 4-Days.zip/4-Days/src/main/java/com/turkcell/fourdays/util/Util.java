package com.turkcell.fourdays.util;

import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

public class Util {
	
	public static void userStatu() {
		
		Authentication aut = SecurityContextHolder.getContext().getAuthentication();
		aut.getName();
		aut.getDetails();
		//aut.setAuthenticated(isAuthenticated);
		Collection<? extends GrantedAuthority> ls = aut.getAuthorities();
		System.out.println("aut.getName() " + aut.getName());
		System.out.println("aut.getDetails() " + aut.getDetails());
		System.out.println("ls : " + ls.toArray()[0]);
		
	}

}
